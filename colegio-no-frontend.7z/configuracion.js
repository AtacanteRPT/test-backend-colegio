global.PORT = 1337;
global.DOMINIO = "http://localhost:1337/"
