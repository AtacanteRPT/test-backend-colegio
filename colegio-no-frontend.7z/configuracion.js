global.PORT = 1337;
global.DOMINIO = "http://localhost:1337/"
global.DOMINIO_A2HOSTING = "http://moswara.com:48000/"
